(() => {
  'use strict';
// Windows 客户端 location 可能带盘符（/D:/plugin/...），相对 fetch 会 400。
// 以当前 script URL 为绝对基址（与 aliyundrive/115 插件一致）。
  function pluginAssetBase() {
    const loaded = document.currentScript?.src
      || [...document.scripts].map((s) => s.src).find((src) => /\/app(?:\.bundle)?\.js(?:$|\?)/.test(src));
    if (loaded) {
      const url = new URL(loaded);
      const cleanPath = url.pathname.replace(/^\/[A-Za-z]:/, '');
      return new URL(cleanPath.replace(/[^/]*$/, ''), url.origin).href;
    }
    const route = window.__MICRO_APP_BASE_ROUTE__;
    if (typeof route === 'string' && route) {
      const cleaned = route.replace(/^\/[A-Za-z]:/, '') || route;
      const normalized = cleaned.endsWith('/') ? cleaned : `${cleaned}/`;
      return new URL(normalized, window.location.origin).href;
    }
    const dir = window.location.pathname.replace(/^\/[A-Za-z]:/, '').replace(/[^/]*$/, '');
    return new URL(dir || '/', window.location.origin).href;
  }
  const assetUrl = (path) => new URL(path, pluginAssetBase()).href;

  const icons = __ICON_ASSETS__;
  const root = document.querySelector('#tr-app');
  const $ = (s) => root.querySelector(s);
  const session = document.querySelector('meta[name="tr-session"]').content;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const escape = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = (name) => `<img src="${icons[name]}" alt="">`;
  root.querySelectorAll('[data-icon]').forEach(el => el.src = icons[el.dataset.icon]);
  let state, items = [], browsePath = '', browseTarget = '', toastTimer, polling = false, generation = 0, consoleOpen = false;
  const fieldIds = { download: '#downloadPath', config: '#configPath', watch: '#watchPath' };
  const bytes = (n) => {
    n = Number(n || 0);
    const u = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
    let i = 0;
    while (n >= 1024 && i < 4) { n /= 1024; i++; }
    return n.toFixed(i ? 1 : 0) + ' ' + u[i];
  };
  const TR_STATUS_LABEL = {
    0: '已停止', 1: '等待校验', 2: '校验中', 3: '等待下载', 4: '等待做种',
    5: '下载中', 6: '下载中', 7: '做种中', 8: '做种中',
  };
  const isStopped = (s) => s === 0;

  function toast(message) {
    $('#toast').textContent = message;
    $('#toast').hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { $('#toast').hidden = true; }, 6500);
  }
  function showError(message) {
    const box = $('#error');
    box.textContent = message || '';
    box.hidden = !message;
  }
  async function api(route, data) {
    const response = await fetch(assetUrl('api/' + route), {
      method: data === undefined ? 'GET' : 'POST',
      cache: 'no-store',
      headers: {
        'X-TR-Session': session,
        'X-CSRF-Token': csrf,
        ...(data === undefined ? {} : { 'Content-Type': 'application/json' }),
      },
      body: data === undefined ? undefined : JSON.stringify(data),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok) throw new Error(result.error || '请求失败');
    return result;
  }
  async function busy(button, fn) {
    button.disabled = true;
    try { await fn(); } catch (e) { toast(e.message); } finally { button.disabled = false; }
  }
  function showConsole(on) {
    consoleOpen = !!on;
    const status = $('#statusView');
    const view = $('#consoleView');
    if (status) status.hidden = !!on;
    if (view) view.hidden = !on;
    if (on) {
      if (location.hash !== '#console') location.hash = 'console';
    } else if (location.hash === '#console') {
      history.replaceState(null, '', location.pathname + location.search);
    }
  }
  function stateLabel(current) {
    if (current.busy) return '正在处理，请稍候';
    if (!current.configured) return '未初始化';
    if (!current.running) return '已停止';
    return current.ready ? '服务运行中' : '容器已启动，等待 Transmission 就绪';
  }
  function render(current) {
    $('#serviceState').textContent = stateLabel(current);
    const dot = current.busy ? '' : (current.running && current.ready ? 'on' : 'off');
    $('#statusDot').className = dot ? 'status-dot ' + dot : 'status-dot';
    const info = [];
    if (current.imageVersion) info.push('镜像 ' + current.imageVersion);
    if (current.preview) info.push('预览模式，不会操作 Docker');
    $('#serviceInfo').textContent = info.join(' · ');
    $('#serviceInfo').hidden = !info.length;

    $('#setup').hidden = current.configured || current.busy;
    $('#serviceActions').hidden = !current.configured;
    const live = current.configured && current.running;
    $('#access').hidden = !live;
    $('#address').textContent = current.address || '（请从设备所有者的小米客户端打开插件以获取地址）';
    $('#toggleService').disabled = current.busy;
    $('#toggleService').textContent = current.running ? '停止服务' : '启动服务';
    $('#downloadDir').textContent = current.download ? '/' + current.download : '—';
    $('#configDir').textContent = current.config ? '/' + current.config : '—';
    $('#watchDir').textContent = current.watch ? '/' + current.watch : '—';
    $('#username').textContent = current.username || '—';
    renderPortState(current);
    if (!current.busy) showError(current.error);
  }
  function renderPortState(current) {
    const port = current.port || {};
    const value = port.peerPort || 51413;
    let text = `BT 端口 ${value} 状态未测试`;
    if (port.testedAt) {
      text = port.open
        ? `BT 端口 ${value} 公网可达`
        : `BT 端口 ${value} 仅局域网可达 · 需在路由器转发 TCP+UDP`;
    }
    $('#portState').textContent = current.busy ? '正在测试端口…' : text;
    $('#testPort').disabled = current.busy || !current.configured || !current.running;
  }
  function renderTasks() {
    const search = $('#search').value.toLowerCase();
    const filter = $('#filter').value;
    const visible = items.filter(item => {
      const name = String(item.name || '').toLowerCase();
      if (search && !name.includes(search)) return false;
      if (filter === 'downloading') return !isStopped(item.status) && item.progress < 1;
      if (filter === 'completed') return item.progress >= 1;
      if (filter === 'stopped') return isStopped(item.status);
      return true;
    });
    $('#count').textContent = `${visible.length} 个任务`;
    $('#empty').hidden = visible.length > 0;
    $('#tasks').innerHTML = visible.map(item => {
      const stopped = isStopped(item.status);
      const label = TR_STATUS_LABEL[item.status] || ('状态 ' + item.status);
      return `<article class="task"><div class="task-body">
        <strong class="task-name">${escape(item.name)}</strong>
        <progress max="1" value="${Math.max(0, Math.min(1, Number(item.progress) || 0))}" aria-label="下载进度"></progress>
        <small>${(Number(item.progress || 0) * 100).toFixed(1)}% · ${bytes(item.size)} · ${escape(label)} · ↓ ${bytes(item.dlspeed)}/s · ↑ ${bytes(item.upspeed)}/s${item.error ? ' · ' + escape(item.error) : ''}</small>
      </div><div class="task-actions">
        <button title="${stopped ? '继续' : '暂停'}" aria-label="${stopped ? '继续' : '暂停'}" data-action="${stopped ? 'start' : 'stop'}" data-id="${item.id}">${icon(stopped ? 'play' : 'stop')}</button>
        <button title="移除任务，保留文件" aria-label="移除任务，保留文件" data-action="remove" data-id="${item.id}">${icon('trash')}</button>
      </div></article>`;
    }).join('');
  }
  async function browse(path) {
    browsePath = path;
    const current = ++generation;
    $('#browsePath').textContent = path ? '/' + path : '用户存储根目录';
    $('#folders').textContent = '正在读取';
    $('#selectFolder').disabled = true;
    $('#up').disabled = !path;
    try {
      const result = await api('browse?path=' + encodeURIComponent(path));
      if (current !== generation) return;
      $('#folders').innerHTML = result.items.map(item =>
        `<button type="button" data-folder="${escape(item.path)}">${icon('folder')}${escape(item.name)}</button>`
      ).join('') || '<p class="muted">此目录下没有子文件夹</p>';
      $('#selectFolder').disabled = !path;
    } catch (e) {
      if (current === generation) $('#folders').textContent = e.message;
    }
  }
  async function refresh() {
    if (polling) return;
    polling = true;
    try {
      const current = await api('status');
      state = current;
      render(current);
      if (consoleOpen || location.hash === '#console') {
        if (!current.running) {
          items = [];
          renderTasks();
          showError('Transmission 未运行，请先启动服务');
        } else {
          try {
            const result = await api('torrents');
            items = result.items || [];
            const t = result.transfer || {};
            $('#downSpeed').textContent = bytes(t.dlspeed) + '/s';
            $('#upSpeed').textContent = bytes(t.upspeed) + '/s';
            $('#downloaded').textContent = bytes(t.downloaded);
            showError('');
            renderTasks();
          } catch (e) {
            items = [];
            renderTasks();
            showError(e.message);
          }
        }
      }
    } catch (e) {
      showError(e.message);
    } finally {
      polling = false;
    }
  }
  root.addEventListener('click', e => {
    const button = e.target.closest('button');
    if (!button) return;
    if (button.dataset.close) { $('#' + button.dataset.close).close(); return; }
    if (button.dataset.folder !== undefined) { browse(button.dataset.folder); return; }
    if (button.classList.contains('choose')) {
      browseTarget = button.dataset.target;
      $('#browse').showModal();
      browse($(fieldIds[browseTarget]).value);
      return;
    }
    if (button.dataset.action && button.dataset.id) {
      busy(button, async () => {
        await api(button.dataset.action, { id: Number(button.dataset.id) });
        await refresh();
      });
    }
  });
  $('#refresh').onclick = () => busy($('#refresh'), refresh);
  $('#up').onclick = () => browse(browsePath.split('/').slice(0, -1).join('/'));
  $('#selectFolder').onclick = () => {
    if (browseTarget && fieldIds[browseTarget]) $(fieldIds[browseTarget]).value = browsePath;
    $('#browse').close();
  };
  $('#copyAddress').onclick = () => busy($('#copyAddress'), async () => {
    const text = $('#address').textContent;
    try {
      await navigator.clipboard.writeText(text);
      toast('已复制地址');
    } catch (e) {
      toast('复制失败，请手动记录：' + text);
    }
  });
  $('#testPort').onclick = () => busy($('#testPort'), async () => {
    await api('service/port-test', {});
    toast('端口测试完成');
    await refresh();
  });
  $('#setupForm').onsubmit = e => {
    e.preventDefault();
    const form = e.target;
    const payload = {
      download: form.elements.download.value,
      config: form.elements.config.value,
      watch: form.elements.watch.value,
      username: form.elements.username.value.trim(),
      password: form.elements.password.value,
    };
    if (!payload.download || !payload.config || !payload.watch) {
      showError('请分别选择下载目录、配置文件夹目录和监控目录');
      return;
    }
    busy(form.querySelector('[type=submit]'), async () => {
      await api('service/setup', payload);
      form.elements.password.value = '';
      await refresh();
    });
  };
  $('#toggleService').onclick = () => busy($('#toggleService'), async () => {
    await api('service/' + (state && state.running ? 'stop' : 'start'), {});
    await refresh();
  });
  const openBtn = $('#openConsole');
  if (openBtn) openBtn.onclick = () => { showConsole(true); busy(openBtn, refresh); };
  const backBtn = $('#backToStatus');
  if (backBtn) backBtn.onclick = () => showConsole(false);
  const searchInput = $('#search');
  if (searchInput) searchInput.oninput = renderTasks;
  const filterEl = $('#filter');
  if (filterEl) filterEl.onchange = renderTasks;
  const addBtn = $('#add');
  if (addBtn) addBtn.onclick = () => { $('#addForm').reset(); $('#addDialog').showModal(); };
  const addForm = $('#addForm');
  if (addForm) addForm.onsubmit = e => {
    e.preventDefault();
    const form = e.target;
    const magnet = form.elements.magnet.value.trim();
    if (!magnet) { toast('请填写磁力链接'); return; }
    busy(form.querySelector('[type=submit]'), async () => {
      await api('magnet', { url: magnet });
      $('#addDialog').close();
      await refresh();
      toast('任务已添加');
    });
  };
  window.addEventListener('hashchange', () => showConsole(location.hash === '#console'));
  if (location.hash === '#console') showConsole(true);
  async function tick() {
    if (!root.isConnected) return;
    if (!document.hidden) await refresh();
    setTimeout(tick, 3000);
  }
  tick();
})();

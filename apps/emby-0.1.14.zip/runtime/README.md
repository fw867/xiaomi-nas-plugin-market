# Emby

小米智能存储插件市场的 Emby 插件，版本 **0.1.0**。不是 Emby 官方插件，也不代表 Emby 官方背书。

## 安装与使用

1. 安装本仓库新版插件市场，在列表中安装「Emby」。此步骤只安装插件，不启动容器。
2. 使用设备所有者账号打开插件。选择媒体目录（视频、音乐所在的父目录，也可以直接选择用户存储根目录）。该目录在容器内以**只读**方式挂载为 `/mnt/media`。
3. 点「初始化并启动」。首次需要从 Docker Hub 拉取官方镜像（arm64 约 150 MiB 压缩），可能需要数分钟。
4. 服务就绪后，用浏览器打开插件页显示的局域网地址（`http://<NAS>:8096`）完成 Emby 初始化向导：选择语言、创建管理员账号，然后在 Emby 中添加媒体库，路径选 `/mnt/media/...`。
5. 之后电视、手机等 Emby 客户端直接连接 `http://<NAS>:8096` 即可。

## 隔离与生命周期

- 独立容器 `xiaomi-plugin-emby`，只挂载配置目录（`/config`）和所选媒体目录（`/mnt/media`）。不挂载 Docker socket，不使用 privileged 或 host 网络。
- 配置目录（Emby 的数据库、缓存、插件与日志，约十几 MB）默认放在插件私有目录，外部不可见；初始化时也可以指定存储中的一个目录，便于备份、迁移或直接在文件管理器里查看。指定时插件不会改动该目录现有文件的属主，建议选空目录或已有的 Emby 配置目录。
- Python 管理服务需 root/Docker 权限，仅提供固定操作（初始化、启动、停止）。它不是不受信任插件的沙箱；安装之前应信任发行者及其签名。
- 1 GiB 容器内存上限、2 CPU 上限、512 PID。是上限，不是恒定资源占用。
- 插件页仅绑定 NAS 回环端口 18150，通过现有设备同源入口访问，不写死 NAS IP。
- Emby 本体使用 Emby 默认端口 **8096**，按媒体服务器的实际需要发布到局域网（否则客户端无法连接）。该端口是明文 HTTP，请自行评估内网可信度；需要加密时可在 Emby 内启用 HTTPS。
- **在初始化向导完成前，同网段任何设备都可能抢先完成初始化并设置管理员密码，请在启动后立即完成向导。**
- 未映射 `/dev/dri`，不启用硬件转码，转码由 CPU 完成，可能较慢；Emby Premiere 相关功能由 Emby 官方授权决定，与本插件无关。
- 媒体目录按读写挂载：Emby 以所选目录的属主 UID/GID 运行，可在其中新增、修改、删除文件（元数据、封面、字幕、转码产物等）。这与 Emby 的正常预期一致，但意味着 Emby 或其漏洞可以改动该目录，请自行确认已有备份。
- 停止或卸载插件时，systemd `ExecStopPost` 只停止带本插件私有所有权标签的容器，不执行 `docker rm`。容器、Emby 配置与媒体文件都会保留；重装后可继续使用。
- 服务启动前核对媒体目录的 inode/device 与路径，存储变化时拒绝启动。OTA 仍可能移除系统入口/服务，不能保证永不受影响。

## 显式关闭容器健康检查

建容器时写死 `Healthcheck: {"Test": ["NONE"]}`。当前 `emby/embyserver:4.10.0.40`
镜像本身没有 `HEALTHCHECK`，所以现在没有实际效果；写死它是防止上游以后加上。

原因是 Jellyfin 已经踩过这个坑：镜像自带的健康检查会定时打 HTTP 接口，服务端每打
一次就重写 SQLite 的 `-shm`/`-wal`，而配置目录在机械盘上——系统索引服务（fanotify）
被触发后再写 `/nas/sys`，而 `/nas/sys` 是跨两块盘的 RAID1，两块盘每 30 秒被唤醒一次，
永远进不了休眠。定位过程见硬盘休眠插件的
`projects/xiaomi-disk-sleep-plugin/tools/disk-activity-report.py`。

如果将来发现本插件建的容器带上了健康检查（页面状态栏不会显示「健康检查已关」），
插件服务重启或点「启动服务」时会自动重建一次容器去掉它——`/config` 与媒体目录都是
bind 挂载，配置和媒体库不受影响。

## 验证与限制

本版本号按正式版发布，但验收范围仅限本地：自动化测试不能替代真实 RP05 镜像启动、Emby 客户端播放、Mac/手机入口及 Windows 安装验收。未在你的 NAS 上自动拉取镜像或启动容器。

本机预览不调用 Docker、不修改 NAS：

```bash
python3 -m unittest discover -s tests -v
python3 server.py --dev
```

打开 `http://127.0.0.1:18150/`。预览模式下初始化与启停操作会被拒绝，未授权 API 不能读取状态。

## 上游与资产

- [Emby 官网](https://emby.media/) / [官方 Docker 镜像](https://hub.docker.com/r/emby/embyserver)
- 固定镜像 `emby/embyserver:4.10.0.40`，多架构 manifest digest `sha256:3aafff933d3f28d23ed0bc201022abe71c0aa80deb17177566c726b9bbc686c6`（含 amd64 / arm64v8 / arm32v7）。Emby 是第三方专有软件，本仓库不分发其二进制，由使用者确认后自行拉取。
- 插件图标来自 [Icon-Icons](https://icon-icons.com/) 的 Emby 图标（`emby_macos_bigsur_icon_190203.png`），仅用于识别兼容软件，不代表 Emby 官方背书。

const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const statusHint = document.getElementById('statusHint');
const autostartToggle = document.getElementById('autostartToggle');
const methodSelect = document.getElementById('methodSelect');
const methodHint = document.getElementById('methodHint');
const hookNote = document.getElementById('hookNote');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const note = document.getElementById('note');
const toast = document.getElementById('toast');

let busy = false;
let firstRender = true;

const METHOD_HINTS = {
  cron: '每分钟巡检一次，发现 SSH 没跑就拉起；兼容性最好。',
  hotplug: '存储池挂载时触发一次（钩子内部会等系统关 SSH 后再拉起并复查）。',
  both: '两条路都开：存储池挂载时触发，加上每分钟巡检兜底。',
};

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('visible');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('visible'), 3200);
}

function render(data) {
  const running = Boolean(data.sshRunning);
  statusDot.className = `status-dot ${running ? 'on' : 'off'}`;
  statusText.textContent = running ? 'SSH 正在运行' : 'SSH 已停止';
  statusHint.textContent = running
    ? '可以从局域网用 SSH 登录此设备'
    : 'SSH 端口未监听，远程登录不可用';

  autostartToggle.checked = Boolean(data.autostart);
  const method = data.method || 'cron';
  if (firstRender || document.activeElement !== methodSelect) methodSelect.value = method;
  methodHint.textContent = METHOD_HINTS[method] || METHOD_HINTS.cron;
  methodSelect.disabled = busy;
  startBtn.disabled = busy || running;
  stopBtn.disabled = busy || !running;

  const hook = data.hotplug || {};
  const wantsHook = Boolean(data.autostart) && (method === 'hotplug' || method === 'both');
  if (wantsHook && !hook.installed) {
    hookNote.hidden = false;
    hookNote.textContent = `存储池钩子未安装（应为 ${hook.path || '/etc/syshotplug/pool/98.ssh-control'}），请重新选择一次守护方式。`;
  } else if (wantsHook && hook.installed && hook.upToDate === false) {
    hookNote.hidden = false;
    hookNote.textContent = '存储池钩子版本较旧（插件升级后需重新安装），请重新选择一次守护方式。';
  } else if (wantsHook && hook.installed && hook.persisted === false) {
    hookNote.hidden = false;
    hookNote.textContent = '存储池钩子已安装，但没落在持久层，重启后可能失效（请检查存储挂载）。';
  } else {
    hookNote.hidden = true;
  }

  const how = { cron: '每分钟巡检', hotplug: '存储池挂载时', both: '存储池挂载 + 每分钟巡检' }[method];
  note.textContent = data.autostart
    ? `开机自启已开启（${how}）：系统每次启动后会自动把 SSH 拉回来。`
    : '开机自启已关闭：小 Mi 系统会在每次开机时关闭 SSH，手动启动只在本次开机内有效。';
  firstRender = false;
}

// Windows 客户端 location 可能带盘符（/D:/plugin/...），相对 fetch 会 400。
// 以当前 script URL 为绝对基址（与 aliyundrive/115 插件一致）。
function pluginAssetBase() {
  const loaded = document.currentScript?.src
    || [...document.scripts].map((s) => s.src).find((src) => /\/app(?:\.bundle)?\.js(?:$|\?)/.test(src));
  if (loaded) return new URL('./', loaded).href;
  const route = window.__MICRO_APP_BASE_ROUTE__;
  if (typeof route === 'string' && route) {
    const cleaned = route.replace(/^\/[A-Za-z]:/, '') || route;
    const normalized = cleaned.endsWith('/') ? cleaned : `${cleaned}/`;
    return new URL(normalized, window.location.origin).href;
  }
  const dir = window.location.pathname.replace(/^\/[A-Za-z]:/, '').replace(/[^/]*$/, '');
  return new URL(dir || '/', window.location.origin).href;
}
const assetUrl = (path) => new URL(path, pluginAssetBase()).href;

async function request(path, body) {
  const init = { method: body ? 'POST' : 'GET', cache: 'no-store' };
  if (body) {
    init.headers = { 'Content-Type': 'application/json' };
    init.body = JSON.stringify(body);
  }
  const response = await fetch(assetUrl(`api${path}`), init);
  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new Error(`服务返回异常（HTTP ${response.status}）`);
  }
  if (!response.ok || !payload.ok) throw new Error(payload.error || '操作失败');
  return payload;
}

async function refresh() {
  try {
    render(await request('/status'));
  } catch (error) {
    statusDot.className = 'status-dot off';
    statusText.textContent = '无法读取状态';
    statusHint.textContent = error.message;
    startBtn.disabled = true;
    stopBtn.disabled = true;
  }
}

async function act(fn, successMessage) {
  if (busy) return;
  busy = true;
  try {
    const data = await fn();
    render(data);
    if (successMessage) showToast(successMessage);
  } catch (error) {
    showToast(error.message);
    await refresh();
  } finally {
    busy = false;
  }
}

startBtn.addEventListener('click', () =>
  act(() => request('/action', { action: 'start' }), 'SSH 已启动'));

stopBtn.addEventListener('click', () =>
  act(() => request('/action', { action: 'stop' }), 'SSH 已停止，开机自启同时关闭'));

autostartToggle.addEventListener('change', () => {
  const enabled = autostartToggle.checked;
  autostartToggle.disabled = true;
  act(
    () => request('/autostart', { enabled, method: methodSelect.value }),
    enabled ? '已开启开机自启' : '已关闭开机自启',
  ).finally(() => { autostartToggle.disabled = false; });
});

methodSelect.addEventListener('change', () => {
  const method = methodSelect.value;
  methodSelect.disabled = true;
  act(
    () => request('/method', { method }),
    `守护方式已切换为「${(METHOD_HINTS[method] || '').split('；')[0]}」`,
  ).finally(() => { methodSelect.disabled = false; });
});

document.getElementById('refreshButton').addEventListener('click', refresh);
/* 小米客户端在 WebView 里注入 flutter_inappwebview / android_webview，官方插件靠自带的
   js-bridge.js 调宿主方法。这里只实现我们用到的那一小部分：调宿主方法并忽略返回结果。 */
function callClient(method, params) {
  const host = window.flutter_inappwebview || window.android_webview;
  if (!host) return false;
  if (!host.callHandler) {
    // 部分客户端版本只暴露 _callHandler，照 js-bridge.js 的方式补一层
    host.callHandler = function () {
      const id = window.setTimeout(() => {});
      host._callHandler(arguments[0], id, JSON.stringify([].slice.call(arguments, 1)));
      return new Promise((resolve) => { host[id] = resolve; });
    };
  }
  const payload = host === window.android_webview ? JSON.stringify(params || {}) : (params || {});
  host.callHandler('hs_webCallAppHandler', method, payload, String(++callClient.seq));
  return true;
}
callClient.seq = 0;
// 宿主拿结果时会回调这个全局函数；我们不等结果，留个空实现免得它报错
window.hs_appCallBackToWeb = window.hs_appCallBackToWeb || function () {};

document.getElementById('backButton').addEventListener('click', () => {
  // 客户端里没有页面历史，window.close() 也会被 WebView 忽略，
  // 只能请宿主关掉当前插件页面
  if (callClient('normal_goback', {})) return;
  if (history.length > 1) {
    history.back();
    return;
  }
  window.close();
});

refresh();

# Transmission 下载（Docker）

小米智能存储插件市场的 Transmission 插件，版本 **0.2.0**。  
本版改为 **Docker 容器** 运行 LinuxServer 的 Transmission 镜像，配置页参考 qB 下载。

**不是 Transmission 或小米的官方插件。**

## 功能

- 配置页可设置：
  - 下载目录 → 容器 `/downloads`
  - 配置文件夹目录 → 容器 `/config`
  - 监控目录 → 容器 `/watch`
  - WebUI 用户名 / 密码
- 端口映射：
  - WebUI / RPC：`tcp 9091`
  - BT 入站：`tcp/udp 51413`
- 服务启停、局域网 WebUI 入口展示

## 安装与使用

1. 安装本插件后，用设备所有者账号打开插件页。
2. 分别选择下载、配置、监控三个目录（必须同属一个 NAS 用户，且互不相同）。
3. 设置 WebUI 用户名与密码（密码至少 8 位，大小写/数字/符号至少两类）。
4. 同意并「安装并启动」。首次需拉取镜像，可能需要数分钟。
5. 服务就绪后，状态页会显示局域网 `http://<NAS-IP>:9091`，用安装时的账号密码登录完整 WebUI。

## 隔离与生命周期

- 容器名：`xiaomi-plugin-transmission`
- 只挂载所选三个目录，不挂载 Docker socket，不使用 privileged / host 网络
- 资源上限：512 MiB 内存、1.5 CPU、128 PID
- WebUI 账号密码通过镜像 `USER`/`PASS` 环境变量注入；`settings.json` 只写目录与端口等非鉴权项
- 停止/卸载插件只停止容器，不删除配置与下载文件
- **旧版原生（Entware 随包二进制）配置不会自动迁移**，升级后需重新初始化

## 镜像

- `lscr.io/linuxserver/transmission@sha256:1a12fef3c89eca48b7be9e7d36b17b4eb4e1bcf5e1ee7fbf372e3a38b562939d`
- 版本：Transmission **4.1.3** / LinuxServer **ls362**（多架构，含 arm64）

## 本地预览

```bash
python3 scripts/build_ui.py
python3 -m unittest discover -s tests -v
python3 server.py --dev
```

打开 `http://127.0.0.1:18140/`。预览模式不会操作 Docker、不会修改 NAS。

## 上游

- [Transmission](https://transmissionbt.com/)
- [LinuxServer Transmission 镜像](https://docs.linuxserver.io/images/docker-transmission/)
